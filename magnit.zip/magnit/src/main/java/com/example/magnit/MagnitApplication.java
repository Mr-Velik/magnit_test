package com.example.magnit;

import com.example.magnit.Service.TestService;
import com.example.magnit.Tests.CreateXml;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.Scanner;

@SpringBootApplication
public class MagnitApplication {

	private static TestService testService;

	private static CreateXml createXml;

	@Autowired
	public void setCreateXml(CreateXml createXml) {
		this.createXml = createXml;
	}

	@Autowired
	public void setTestService(TestService testService) {
		this.testService = testService;
	}

	public static void main(String[] args) {
		SpringApplication.run(MagnitApplication.class, args);
		System.out.println("Введите число");
		Scanner scanner = new Scanner(System.in);
		if(scanner.hasNextInt()){
			testService.addAll(scanner.nextInt());
		}
		createXml.xmlDoc();

//		testService.addAll((Integer.parseInt(args[0].trim())));
//		SpringApplication.run(MagnitApplication.class, args);

	}

}
//	mvn spring-boot:run -Drun.arguments=--10