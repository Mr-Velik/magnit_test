package com.example.magnit.Service;

import com.example.magnit.Model.Test;

import java.util.List;

public interface TestService {

   public Test findById(Long id);

   public List<Test> findAll();

   public void addAll(int n);

}
