package com.example.magnit.Tests;

import com.example.magnit.Model.Test;
import com.example.magnit.Service.TestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

@Component
public class CreateXml {
    private TestService testService;

    @Autowired
    public void setTestService(TestService testService) {
        this.testService = testService;
    }

     private List<Test> list = new ArrayList<>();


    public final String xmlFilePath = "C:\\Users\\user\\IdeaProjects\\Magnit\\1.xml";

    public void xmlDoc() {

        try {
//            List<Test> list = this.testService.findAll();
            DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();

            DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();

            Document document = documentBuilder.newDocument();

            // root element
            Element root = document.createElement("entries");
            document.appendChild(root);

            for(int i = 0; i<= list.size()-1;i++) {
                // employee element
                Element employee = document.createElement("entry");

                root.appendChild(employee);

                // set an attribute to staff element
//            Attr attr = document.createAttribute("id");
//            attr.setValue("10");
//            employee.setAttributeNode(attr);

                //you can also use staff.setAttribute("id", "1") for this

                // firstname element
                Element firstName = document.createElement("field");
                employee.appendChild(firstName);

                // lastname element


                // email element


                // department elements

            }

            // create the xml file
            //transform the DOM Object to an XML File
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource domSource = new DOMSource(document);
            StreamResult streamResult = new StreamResult(new File(xmlFilePath));

            // If you use
            // StreamResult result = new StreamResult(System.out);
            // the output will be pushed to the standard output ...
            // You can use that for debugging

            transformer.transform(domSource, streamResult);

            System.out.println("Done creating XML File");

        } catch (ParserConfigurationException pce) {
            pce.printStackTrace();
        } catch (TransformerException tfe) {
            tfe.printStackTrace();
        }
    }
}
