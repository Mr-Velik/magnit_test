package com.example.magnit.Tests;

import com.example.magnit.Service.TestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class InputValues {
    private TestService testService;

    @Autowired
    public void setTestService(TestService testService) {
        this.testService = testService;
    }

    public void add(){
        testService.addAll(10);
    }
}
